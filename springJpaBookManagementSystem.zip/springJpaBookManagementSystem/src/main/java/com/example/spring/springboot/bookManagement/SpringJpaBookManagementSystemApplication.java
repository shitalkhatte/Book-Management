package com.example.spring.springboot.bookManagement;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.example.spring.springboot.bookManagement.Entity.Book;
import com.example.spring.springboot.bookManagement.service.BookService;

@SpringBootApplication
@ComponentScan({"com.example.spring.springboot.bookManagement.service"})
public class SpringJpaBookManagementSystemApplication {
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		ApplicationContext appConfig=SpringApplication.run(SpringJpaBookManagementSystemApplication.class, args);
		BookService b=appConfig.getBean(BookService.class);
		
		l:while(true)
		{
		System.out.println("\n------Menu------\n1.Save Book\n2.ViewAll Books\n3.ViewBookBy Bookid\n4.Delete Book By Id\n5.Exit\n");
		System.out.println("Enter the choice: ");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Enter the book title");
			String name=sc.next();
			System.out.println("Enter the Book Author");
			String author=sc.next();
			System.out.println("Enter the price of book");
			double price=sc.nextDouble();
			System.out.println("Enter the Date in DAy");
			int d=sc.nextInt();
			System.out.println("Enter the Date in Month");
			int m=sc.nextInt();
			System.out.println("Enter the Date in Year");
			int y=sc.nextInt();
			b.saveBook(new Book(name,author,price,LocalDate.of(y,m,d)));
			break;
		case 2:
			List<Book> s=b.getAllBooks();
			s.forEach(books->System.out.println(books));
			break;
		case 3:
			System.out.println("Enter Id to find the Book");
			int id=sc.nextInt();
			Book book=b.getBookById(id);
			System.out.println(book);
			break;
		case 4:
			System.out.println("Enter id to delete the book");
			int id1=sc.nextInt();
			b.deleteBookById(id1);
			System.out.println("Book deleted successfully");
			break;
		case 5:
			break l;
		default:
			System.out.println("Wrong choice");			
		}
		}
	}
}
